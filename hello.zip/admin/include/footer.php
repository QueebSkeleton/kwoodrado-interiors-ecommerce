<footer class="main-footer">
	<strong>Copyright &copy; 2014-2021 <a href="/">Kwoodrado Interiors</a>.</strong>
	All rights reserved.
</footer>
